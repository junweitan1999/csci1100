import life
conf = ['init06.life', 4, 'grid_.out.life', 'grid_.out.png', [50, 36, 100, 10], ['blue',
'grey', 'cyan', 'white', ['SpringGreen', 'Lime', 'Olive', 'DarkOliveGreen',
'DarkSeaGreen'], 'MidnightBlue'] ]
grid = life.read_init(conf)
